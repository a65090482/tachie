class AC1 : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class AdvSystem : public Archive
{
protected:
	static const unsigned long BLOCK = 0x64;
	static const unsigned long IGNORE = 0x40;
	unsigned long m_header;
	unsigned long m_data;

public:
	AdvSystem(FILE *in) : Archive(in)
	{
		readarray();
		m_header = read();
		m_data = read();
		m_copy_size = 0x10;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i);
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
		if (m_file[i].orig != m_file[i].size)
		{
			seek(m_file[i].addr);
			unsigned char *buf = read(m_file[i].size);
			unsigned char *outbuf = new unsigned char[m_file[i].orig];
			lzdecode(outbuf, m_file[i].orig, buf, m_file[i].size);
			delete[] buf;
			FILE *out = makefile(outpath, m_file[i].name);
			if (out)
			{
				fwrite(outbuf, 1, m_file[i].orig, out);
				fclose(out);
			}
			delete[] outbuf;
			return true;
		}
		return Archive::extract(i, outpath);
	};
};

int AdvSystem::analyze(int i)
{
	if (over(i)) return false;
	seek(m_header + i*BLOCK);
	m_file[i].name = read(BLOCK);
	unsigned long *buf = (unsigned long*)m_file[i].name;
	for (int j = 0; j < BLOCK/4; j++)
		buf[j] = ~(((buf[j]&0x0F0F0F0F)<<4) | ((buf[j]>>4)&0x0F0F0F0F));
	m_file[i].pos = m_header + i*BLOCK + IGNORE;
	m_file[i].size = buf[0x10];
	m_file[i].addr = buf[0x11] + m_data;
	m_file[i].orig = buf[0x13];
	return true;
};

class AC2 : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)	{return new AdvSystem(in);};
};
const char *AC2::EXT = ".ac2";
class AC3 : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)	{return new AdvSystem(in);};
};
const char *AC3::EXT = ".ac3";
class AC4 : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)	{return new AdvSystem(in);};
};
const char *AC4::EXT = ".ac4";
class AC5 : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)	{return new AdvSystem(in);};
};
const char *AC5::EXT = ".ac5";

const char *AC1::EXT = ".ac1";

Archive* AC1::Check(FILE *in)
{
	return new AdvSystem(in);
};
