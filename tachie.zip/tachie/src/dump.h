class DMP : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class DUMP : public Archive
{
protected:
	unsigned long m_header;
	unsigned long m_block;

public:
	DUMP(FILE *in) : Archive(in)
	{
		unsigned char *buf = read(0x100);
		dump(buf, 0x100);
		delete[] buf;
		seeke(0);
		unsigned long size = ftell(m_in);
		printf("file size:%u\n", size);
		printf("header?:");
		m_header = gets_int();
		printf("block?:");
		m_block = gets_int();
		printf("num?(size/block == %d):", (size-m_header) / m_block);
		m_num = gets_int();
		array();
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, m_block, 0, 0);
	};
	virtual int analyze(int i)
	{
		seek(m_header + i*m_block);
		m_file[i].name = read(m_block);
		return true;
	};
};

const char *DMP::EXT = ".dmp";

Archive* DMP::Check(FILE *in)
{
	return new DUMP(in);
};
