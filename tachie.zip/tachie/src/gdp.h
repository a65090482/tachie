class ggDP : public Archive
{
public:static const unsigned long SIGNATURE = 0x50446767;

protected:
	static const unsigned long HEADER = 0x40;
	static const unsigned long BLOCK = 0x70;
	static const unsigned long IGNORE = 0x60;

public:
	ggDP(FILE *in) : Archive(in)
	{
		seek(0x08);
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = readwc(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read();
		m_file[i].size = read();
		return true;
	};
};
