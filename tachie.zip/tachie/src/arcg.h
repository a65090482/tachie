class ARCG : public Archive
{
public:static const unsigned long SIGNATURE = 0x47435241;

protected:
	unsigned long m_info;

public:
	ARCG(FILE *in) : Archive(in)
	{
		seek(0x08);
		m_info = read();
		m_copy_size = 8;
	};
	virtual int analyze_all();
};

int ARCG::analyze_all()
{
	unsigned long dir_current = m_info;
	while (1)
	{
		seek(dir_current);
		char size = read8();
		if (!size)
			break;
		char *dirname = read(size-1);
		unsigned long addr = read();
		int  num = read();
		dir_current += size + 8;

		m_file.reserve(m_num + num);
		seek(addr);
		for (int j = 0; j < num; j++)
		{
			char size = read8();
			if (!size)
				break;
			int  i = extend();
			int  len = strlen(dirname);
			if (len)
			{
				m_file[i].name = new char[len + 1 + size];
				char *filename = read(size-1);
				sprintf(m_file[i].name, "%s\\%s", dirname, filename);
				delete[] filename;
			}
			else
				m_file[i].name = read(size-1);
			m_file[i].pos = addr + size;
			m_file[i].addr = read();
			m_file[i].size = read();
			addr += size + 8;
		}

		delete[] dirname;
	}

	return 0;
}

class WSM4 : public Archive
{
public:static const unsigned long SIGNATURE = 0x344D5357;

protected:
	static const unsigned long BLOCK = 0x24;
	unsigned long m_header;
	unsigned long m_infonum;
	unsigned long m_info;

public:
	WSM4(FILE *in) : Archive(in)
	{
		seek(0x8);
		m_info = read();
		m_infonum = read();
		m_header = read();
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, BLOCK, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_info + i*0x1A8 + 4);
		char *filename = read(0x40);
		char *title = read(0x80);
		m_file[i].name = new char[0xC8];
		sprintf(m_file[i].name, "%s[%s].ogg", filename, title);
		delete[] filename;
		delete[] title;
		m_file[i].pos = m_header + i*BLOCK;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		m_file[i].size = read();
		return true;
	};
};
