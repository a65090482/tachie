class CLS : public Archive
{
public:static const unsigned long SIGNATURE = 0x5F534C43;

protected:
	static const unsigned long HEADER = 0x40;
	static const unsigned long BLOCK = 0x40;
	static const unsigned long IGNORE = 0x28;

public:
	CLS(FILE *in) : Archive(in)
	{
		seek(0x10);
		readarray();
		m_copy_size = 0x0C;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		seekc(4);
		m_file[i].addr = read();
		m_file[i].size = read();
		return true;
	};
};
