class BGI : public Archive
{
public:static const unsigned long SIGNATURE = 0x6B636150;

protected:
	static const unsigned long HEADER = 0x10;
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x10;

public:
	BGI(FILE *in) : Archive(in)
	{
		seek(0x0C);
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read();
		m_file[i].size = read();
		return true;
	};
};

class BURIKO_ARC2 : public Archive
{
public:static const unsigned long SIGNATURE = 0x49525542;

protected:
	static const unsigned long HEADER = 0x10;
	static const unsigned long BLOCK = 0x80;
	static const unsigned long IGNORE = 0x60;

public:
	BURIKO_ARC2(FILE *in) : Archive(in)
	{
		seek(0x0C);
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read() + HEADER + m_num*BLOCK;
		m_file[i].size = read();
		return true;
	};
};
