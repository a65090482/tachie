class DPMX : public Archive
{
public:static const unsigned long SIGNATURE = 0x584D5044;

protected:
	static const unsigned long HEADER = 0x10;
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x14;
	unsigned long m_data;

public:
	DPMX(FILE *in) : Archive(in)
	{
		seek(4);
		m_data = read();
		readarray();
		m_copy_size = 0xC;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(0x10);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		seekc(8);
		m_file[i].addr = read() + m_data;
		m_file[i].size = read();
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
/*		if (!strnicmp(m_file[i].name + strlen(m_file[i].name) - 4, ".bmp", 4))
		{
			int mask = read8() ^ 'B';
			return extractB(i, outpath, mask);
		}
		else*/
		{
			return Archive::extract(i, outpath);
		}
	};
};
