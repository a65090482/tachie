class eme : public Archive
{
public:static const unsigned long SIGNATURE = 0x44455252;

protected:
	static const unsigned long BLOCK = 0x60;
	static const unsigned long BLOCK32 = 0x18;
	static const unsigned long IGNORE = 0x4C;
	static const unsigned long COPY = 0x14;
	unsigned long m_header;
	unsigned char m_decode_info[8];
	unsigned long m_decode_key[8];
	unsigned long *m_info;
	unsigned long m_decode;
	void decode1(unsigned long *data, unsigned long key);
	void decode2(unsigned long *data, unsigned long key);
	void decode4(unsigned long *data, unsigned long key);
	void decode8(unsigned long *data, unsigned long key);
	void decode(unsigned long *data);
	void encode1(unsigned long *data, unsigned long key);
	void encode2(unsigned long *data, unsigned long key);
	void encode4(unsigned long *data, unsigned long key);
	void encode8(unsigned long *data, unsigned long key);
	void encode(unsigned long *data);
	void write(FILE *bak);

public:
	eme(FILE *in) : Archive(in)
	{
		seeke(0x04);
		m_header = ftell(m_in);
		readarray();
		m_header -= m_num * BLOCK;
		seek(m_header - 0x28);
		fread(m_decode_info, 1, 8, m_in);
		fread(m_decode_key, 4, 8, m_in);
		m_info = new unsigned long[m_num*BLOCK32];
		m_decode = false;
		m_copy_size = COPY;
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_header + i*BLOCK);

		unsigned long *data = m_info + i*BLOCK32;
		fread(data, 4, BLOCK32, m_in);
		decode(data);

		m_file[i].name = newcopy((unsigned char *)data);
		m_file[i].pos = m_header + i * BLOCK;
		m_file[i].size = data[19];
		m_file[i].addr = data[21];
		return true;
	};
	virtual int process(int dest, int src, FILE *bak);
	virtual ~eme()
	{
		delete [] m_info;
	}
};

void eme::decode1(unsigned long *data, unsigned long key)
{
	for (int i = 0; i < BLOCK32; i++)
		data[i] ^= key;
}

void eme::decode2(unsigned long *data, unsigned long key)
{
	for (int i = 0; i < BLOCK32; i++)
	{
		data[i] ^= key;
		key ^= data[i];
	}
}

void eme::decode4(unsigned long *data, unsigned long key)
{
	for (int i = 0; i < BLOCK32; i++)
	{
		int  temp = 0;
		int  result = 0;
		for (int j = 0; j < 0x20; j++)
		{
			temp += key;
			temp &= 0x1F;
			if ((data[i] >> j) & 1)
			{
				result |= 1 << temp;
			}
		}
		data[i] = result;
	}
}

void eme::decode8(unsigned long *data, unsigned long key)
{
	unsigned char *byte = (unsigned char *)data;
	unsigned long temp_data[BLOCK32];
	unsigned char *temp = (unsigned char *)temp_data;
	int  cur = 0;
	for (int i = 0; i < BLOCK; i++)
	{
		cur += key;
		cur %= BLOCK;
		temp[cur] = byte[i];
	}

	for (int i = 0; i < BLOCK32; i++)
		data[i] = temp_data[i];
}

void eme::decode(unsigned long *data)
{
	for (int info = 7; info >= 0; info--)
	{
		unsigned long key = m_decode_key[info];
		if (m_decode_info[info])
			m_decode = true;
		switch (m_decode_info[info])
		{
		case 8:
			decode8(data, key);
			break;
		case 4:
			decode4(data, key);
			break;
		case 2:
			decode2(data, key);
			break;
		case 1:
			decode1(data, key);
			break;
		}
	}
}

void eme::encode1(unsigned long *data, unsigned long key)
{
	decode1(data, key);
}

void eme::encode2(unsigned long *data, unsigned long key)
{
	for (int i = 0; i < BLOCK32; i++)
	{
		data[i] ^= key;
		key = data[i];
	}
}

void eme::encode4(unsigned long *data, unsigned long key)
{
	for (int i = 0; i < BLOCK32; i++)
	{
		int  temp = 0;
		int  result = 0;
		for (int j = 0; j < 0x20; j++)
		{
			temp += key;
			temp &= 0x1F;
			if ((data[i] >> temp) & 1)
			{
				result |= 1 << j;
			}
		}
		data[i] = result;
	}
}

void eme::encode8(unsigned long *data, unsigned long key)
{
	unsigned char *byte = (unsigned char *)data;
	unsigned long temp_data[BLOCK32];
	unsigned char *temp = (unsigned char *)temp_data;
	int  cur = 0;
	for (int i = 0; i < BLOCK; i++)
	{
		cur += key;
		cur %= BLOCK;
		temp[i] = byte[cur];
	}

	for (int i = 0; i < BLOCK32; i++)
		data[i] = temp_data[i];
}

void eme::encode(unsigned long *data)
{
	for (int info = 0; info < 8; info++)
	{
		unsigned long key = m_decode_key[info];
		switch (m_decode_info[info])
		{
		case 8:
			encode8(data, key);
			break;
		case 4:
			encode4(data, key);
			break;
		case 2:
			encode2(data, key);
			break;
		case 1:
			encode1(data, key);
			break;
		}
	}
}

void eme::write(FILE *bak)
{
	seek(m_header - 0x28);
	unsigned char *buf = read(0x28 + m_num*BLOCK);
	backup(m_header - 0x28, buf, 0x28 + m_num*BLOCK, bak);
	delete [] buf;

	seek(m_header - 0x28);
	for (int i = 0; i < 8; i++)
	{
		char c = 0;
		fwrite(&c, 1, 1, m_in);
	}
	for (int i = 0; i < 8; i++)
	{
		long l = 0;
		fwrite(&l, 4, 1, m_in);
	}
	fwrite(m_info, 0x60, m_num, m_in);
	m_decode = false;
}

int eme::process(int dest, int src, FILE *bak)
{
/*
	if (m_decode)
	{
		write(bak);
		bak = NULL;
	}
	return Archive::process(dest, src, bak);
*/
	unsigned long buf[BLOCK32];
	seek(m_file[dest].pos);
	fread(buf, 4, BLOCK32, m_in);
	backup(m_file[dest].pos, buf, BLOCK, bak);

	int  i;
	for (i = 0; i < IGNORE/4; i++)
		buf[i] = m_info[dest*BLOCK32 + i];
	for (; i < BLOCK32; i++)
		buf[i] = m_info[src*BLOCK32 + i];

	encode(buf);
	seek(m_file[dest].pos);
	fwrite(buf, 4, BLOCK32, m_in);
	return 0;
}
