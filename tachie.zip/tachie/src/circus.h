class FilePack1 : public Archive
{
public:static const unsigned long SIGNATURE = 0x656C6946;

protected:
	static const unsigned long HEADER = 0x18;
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x18;
	static const unsigned long MASK = 0xAAAAAAAA;

public:
	FilePack1(FILE *in) : Archive(in)
	{
		seek(0x10);
		array(read() ^ MASK);
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		maskbuf(m_file[i].name, IGNORE, MASK);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read() ^ MASK;
		m_file[i].size = read() ^ MASK;
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		return extractB(i, outpath, 0xFF);
	};
};

class Circus : public Archive
{
protected:
	static const unsigned long HEADER = 0x20;
	static const unsigned long BLOCK = 0x10;
	static const unsigned long IGNORE = 0x08;
	static const unsigned long MASK = 0x38383838;
	unsigned long m_current;

public:
	Circus(FILE *in) : Archive(in)
	{
		seek(0x18);
		array(read() ^ MASK);
		m_current = HEADER + m_num*BLOCK;
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK + 4);
		int  size = read() ^ MASK;
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read() ^ MASK;
		m_file[i].size = read() ^ MASK;
		seek(m_current);
		m_file[i].name = read(size);
		maskbuf(m_file[i].name, size, MASK);
		m_current += size + 1;
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		return extractB(i, outpath, 0x25);
	};
};
