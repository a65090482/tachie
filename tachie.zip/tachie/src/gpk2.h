class GPK2 : public Archive
{
public:static const unsigned long SIGNATURE = 0x324B5047;

protected:
	static const unsigned long BLOCK = 0x88;
	unsigned long header;

public:
	GPK2(FILE *in) : Archive(in)
	{
		seek(0x04);
		header = read();
		seek(header);
		readarray();
		header += 4;
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, header, BLOCK, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(header + i*BLOCK);
		m_file[i].pos = header + i*BLOCK;
		m_file[i].addr = read();
		m_file[i].size = read();
		m_file[i].name = read(0x80);
		return true;
	};
};
