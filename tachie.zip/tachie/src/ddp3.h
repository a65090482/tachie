class DDP3 : public Archive
{
public:static const unsigned long SIGNATURE = 0x33504444;

protected:
	unsigned long m_current;
	unsigned long m_header;
	int  m_version;

	void decode(unsigned char *outbuf, unsigned long outsize, unsigned char *buf, unsigned long size)
	{
		memcpy(outbuf, buf, size);
	};

public:
	DDP3(FILE *in) : Archive(in)
	{
		m_version = 0;
		m_copy_size = 0x10;
	};
	virtual int analyze_all();
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		FILE *out = makefile(outpath, m_file[i].name);
		if (m_file[i].size)
		{
			seek(m_file[i].addr);
			unsigned char *buf = read(m_file[i].size);
			unsigned long outsize = m_file[i].orig;
			unsigned char *outbuf = new unsigned char[outsize];
			decode(outbuf, outsize, buf, m_file[i].size);
			delete[] buf;
			fwrite(outbuf, 1, outsize, out);
			delete[] outbuf;
		}
		else
			copyfile(m_in, m_file[i].addr, m_file[i].orig, out);
		fclose(out);
		return true;
	};
};

int DDP3::analyze_all()
{
	seek(0x04);
	int  num = read();
	unsigned long header = read();
	unsigned long current = 0x20 + num * 0x08;
	while (current < header)
	{
		seek(current);
		char infosize = read8();
		if (!infosize)
		{
			current++;
			continue;
		}
		int  i = extend();
		m_file[i].pos = current+1;
		if (!m_version)
		{
			seekc(4);
			m_file[i].addr = read();
			m_file[i].orig = m_file[i].size = read();
			seekc(4);
		}
		else
		{
			m_file[i].addr = read();
			m_file[i].orig = read();
			m_file[i].size = read();
			seekc(4);
		}
		if (!m_version)
		{
			m_file[i].name = read(infosize - 0x11);
			if (m_file[i].name[1] == 0)
			{
				m_version = 1;
				delete[] m_file[i].name;
				seek(current + 1);
				m_file[i].addr = read();
				m_file[i].orig = read();
				m_file[i].size = read();
				seekc(4);
				m_file[i].name = readwc(infosize - 0x11);
			}
		}
		else
		{
			m_file[i].name = readwc(infosize - 0x11);
		}
		current += infosize;
	}
	return 0;
}
