class fPK : public Archive
{
public:static const unsigned long SIGNATURE = 0x204B5066;

protected:
	static const unsigned long BLOCK = 0x0C;
	static const unsigned long IGNORE = 0x04;
	unsigned long m_header;
	unsigned long *m_info;
	char *m_filename;
	unsigned long m_data;
	unsigned long m_table_l[0x20];
	unsigned short m_table_s[0x20];
	unsigned long maketable(unsigned long key, unsigned long *table_l, unsigned short *table_s);
	unsigned long decode(unsigned long data, unsigned long key);

public:
	fPK(FILE *in);
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = m_header + i*BLOCK + IGNORE;
		m_file[i].addr = m_info[i*3 + 1] + m_data;
		m_file[i].size = m_info[i*3 + 2];
		m_file[i].name = newcopy(m_filename + m_info[i*3]);
		return true;
	};
	virtual int process(int dest, int src, FILE *bak);
	virtual ~fPK()
	{
		DELETE(m_info);
		DELETE(m_filename);
	};
};

unsigned long fPK::maketable(unsigned long key, unsigned long *table_l, unsigned short *table_s)
{
	for (int i = 0; i < 0x20; i++)
	{
		unsigned short temp = 0;
		unsigned long k = (key ^ (key>>1)) & 0x55555555;
		for (int j = 0; j < 0x10; j++)
			temp |= (k>>j) & (1<<j);
		table_l[i] = key;
		table_s[i] = temp;
		key = (key << 1) | (key >> 0x1F);
	}
	return key;
}

unsigned long fPK::decode(unsigned long data, unsigned long key)
{
	unsigned long temp = 0;
	for (int i = 0; i < 0x10; i++)
		temp |= (((key >> i) & 1) ? (((data<<1) & 0xAAAAAAAA) | ((data>>1) & 0x55555555)) : data) & (3 << (i<<1));
	return temp;
}

fPK::fPK(FILE *in) : Archive(in)
{
	m_info = NULL;
	m_filename = NULL;
	m_header = m_data = 0;
	seek(0x04);
	unsigned long end = read();
	unsigned long cur = 0x08;

	while (cur < end)
	{
		unsigned long sig = read();
		unsigned long size = read();
		unsigned long hsize = read();
		unsigned long key;
		switch (sig)
		{
		case 0x54534C63:
		{
			seek(cur + 0x10);
			readarray();
			key = read();
			maketable(key, m_table_l, m_table_s);
			m_header = cur + hsize;
			seek(m_header);
			int  bufsize = (size - hsize) / 4;
			m_info = new unsigned long[bufsize];
			fread(m_info, 4, bufsize, m_in);
			for (int i = 0; i < bufsize; i++)
				m_info[i] = m_table_l[i&0x1F] ^ decode(m_info[i], m_table_s[i&0x1F]);
			break;
		}
		case 0x4D414E63:
		{
			seek(cur + 0x10);
			key = read();
			unsigned long *table_l = new unsigned long[0x20];
			unsigned short *table_s = new unsigned short[0x20];
			maketable(key, table_l, table_s);
			seek(cur + hsize);
			int  bufsize = size - hsize;
			m_filename = read(bufsize);
			unsigned long *data = (unsigned long*)m_filename;
			for (int i = 0; i < bufsize/4; i++)
				data[i] = table_l[i&0x1F] ^ decode(data[i], table_s[i&0x1F]);
			delete[] table_l;
			delete[] table_s;
			break;
		}
		case 0x54414463:
			m_data = cur + hsize;
			break;
		}
		cur += size;
	}
	m_copy_size = 8;
};

int fPK::process(int dest, int src, FILE *bak)
{
	unsigned long buf[2];
	seek(m_file[dest].pos);
	fread(buf, 1, m_copy_size, m_in);
	backup(m_file[dest].pos, buf, m_copy_size, bak);
	buf[0] = decode(m_info[src*3 + 1] ^ m_table_l[(dest*3+1)&0x1F], m_table_s[(dest*3+1)&0x1F]);
	buf[1] = decode(m_info[src*3 + 2] ^ m_table_l[(dest*3+2)&0x1F], m_table_s[(dest*3+2)&0x1F]);
	seek(m_file[dest].pos);
	fwrite(buf, 1, m_copy_size, m_in);
	return 0;
}

class fpk : public Archive
{
public:static const unsigned long SIGNATURE = 0x004B5046;

protected:
	static const unsigned long BLOCK = 0x18;
	static const unsigned long IGNORE = 0x04;
	unsigned long m_header;
	char *m_directory;

public:
	fpk(FILE *in) : Archive(in)
	{
		m_directory = NULL;
		seek(0x08);
		m_header = read();
		readarray();
		seekc(4);
		if (read())
		{
			seek(0x14);
			m_directory = read(8);
		}
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = m_header + i*BLOCK + IGNORE;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		m_file[i].size = read();
		m_file[i].name = read(0x0C);
		if (m_directory)
		{
			char *name = new char[strlen(m_directory) + strlen(m_file[i].name) + 1];
			sprintf(name, "%s%s", m_directory, m_file[i].name);
			delete[] m_file[i].name;
			m_file[i].name = name;
		}
		return true;
	};
	virtual ~fpk()
	{
		DELETEM(m_directory);
	};
};

class FPK : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class INTERHEART : public Archive
{
protected:
	static const unsigned long HEADER = 0x04;
	static const unsigned long BLOCK = 0x20;

public:
	INTERHEART(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = HEADER + i*BLOCK;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		m_file[i].size = read();
		m_file[i].name = read(0x18);
		return true;
	};
};

class CandySoft : public Archive
{
protected:
	unsigned long m_mask;
	unsigned long m_header;
	unsigned long m_block;

public:
	CandySoft(FILE *in) : Archive(in)
	{
		m_num = read() & 0x7FFFFFFF;
		array();
		m_copy_size = 8;
		seeke(8);
		m_mask = read();
		m_header = read();
		m_block = 0x8C;
		seek(m_header);
		unsigned long addr = read() ^ m_mask;
		unsigned long size = read() ^ m_mask;
		seek(m_header + m_block);
		if ((read() ^ m_mask) != (addr + size))
			m_block = 0x24;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, m_block, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = m_header + i*m_block;
		seek(m_file[i].pos);
		m_file[i].addr = read() ^ m_mask;
		m_file[i].size = read() ^ m_mask;
		m_file[i].name = read(m_block - 8);
		maskbuf(m_file[i].name, m_block - 8, (unsigned char*)&m_mask, 4);
		return true;
	};
};

const char *FPK::EXT = ".fpk";

Archive* FPK::Check(FILE *in)
{
	fseek(in, 0, SEEK_SET);
	unsigned long l;
	fread(&l, 4, 1, in);
	if (l & 0x80000000)
		return new CandySoft(in);
	return new INTERHEART(in);
};
