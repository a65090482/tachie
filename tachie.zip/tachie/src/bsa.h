class BSArc : public Archive
{
public:static const unsigned long SIGNATURE = 0x72415342;

protected:
	static const unsigned long BLOCK[2];
	static const unsigned long IGNORE[2];
	unsigned long m_version;
	unsigned long m_header;
	unsigned long m_filename_header;
	char m_directory[1024];

public:
	BSArc(FILE *in) : Archive(in)
	{
		seek(0x08);
		m_version = read16();
		if (m_version == 3)
			m_version = 1;
		else
			m_version = 0;
		m_num = read16();
		m_header = read();
		array();
		m_copy_size = 8;
		m_filename_header = m_header + m_num*BLOCK[m_version];
		m_directory[0] = 0;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, BLOCK[m_version], IGNORE[m_version], m_copy_size);
	};
	virtual int analyze(int i);
};

int BSArc::analyze(int i)
{
	if (over(i)) return false;
	seek(m_header + i*BLOCK[m_version]);
	m_file[i].pos = m_header + i*BLOCK[m_version] + IGNORE[m_version];
	if (m_version)
	{
		unsigned long filename = read();
		m_file[i].addr = read();
		m_file[i].size = read();
		seek(m_filename_header + filename);
		m_file[i].name = read(32);
	}
	else
	{
		m_file[i].name = read(IGNORE[m_version]);
		m_file[i].addr = read();
		m_file[i].size = read();
	}
	if (m_file[i].name[0] == '>')
	{
		strcat(m_directory, &m_file[i].name[1]);
		strcat(m_directory, "\\");
	}
	else if (m_file[i].name[0] == '<')
	{
		int  j;
		for (j = strlen(m_directory)-1; j > 0; j--)
			if (m_directory[j-1] == '\\')
				break;
		m_directory[j] = 0;
	}
	else
	{
		char *filename = new char[strlen(m_directory) + strlen(m_file[i].name) + 1];
		sprintf(filename, "%s%s", m_directory, m_file[i].name);
		delete [] m_file[i].name;
		m_file[i].name = filename;
	}
	return true;
};

const unsigned long BSArc::BLOCK[2] = {0x28, 0x0C};
const unsigned long BSArc::IGNORE[2] = {0x20, 0x04};
