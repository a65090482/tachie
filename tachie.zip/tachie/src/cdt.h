class CDT : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class RK1 : public Archive
{
public:static const unsigned long SIGNATURE = 0x00314B52;

protected:
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x10;
	unsigned long m_header;

public:
	RK1(FILE *in) : Archive(in)
	{
		seeke(0x08);
		readarray();
		m_header = read();
		m_copy_size = 0x10;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_header, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_header + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = m_header + i*BLOCK + IGNORE;
		m_file[i].size = read();
		m_file[i].orig = read();
		seekc(4);
		m_file[i].addr = read();
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
		if (m_file[i].orig != m_file[i].size)
		{
			seek(m_file[i].addr);
			unsigned char *buf = read(m_file[i].size);
			unsigned char *outbuf = new unsigned char[m_file[i].orig];
			lzdecode(outbuf, m_file[i].orig, buf, m_file[i].size);
			delete[] buf;
			FILE *out = makefile(outpath, m_file[i].name);
			if (out)
			{
				fwrite(outbuf, 1, m_file[i].orig, out);
				fclose(out);
			}
			delete[] outbuf;
			return true;
		}
		return Archive::extract(i, outpath);
	};
};

const char *CDT::EXT = ".cdt";

Archive* CDT::Check(FILE *in)
{
	return new RK1(in);
};

class OVD : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)
	{
		return new RK1(in);
	};
};
const char *OVD::EXT = ".ovd";

class PDT : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)
	{
		return new RK1(in);
	};
};
const char *PDT::EXT = ".pdt";

class VDT : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in)
	{
		return new RK1(in);
	};
};
const char *VDT::EXT = ".vdt";
