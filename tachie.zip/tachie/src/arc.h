class ARC : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class _ARC : public Archive
{
public:static const unsigned long SIGNATURE = 0x43524100;

protected:
	unsigned long m_data;
	unsigned long m_current;

public:
	_ARC(FILE *in) : Archive(in)
	{
		seek(4);
		m_data = read();
		readarray();
		m_current = 12;
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_current);
		int  size = read();
		m_file[i].name = readwc(size);
		m_file[i].addr = m_data;
		m_data += m_file[i].size = read();
		m_current += 8 + size;
		return true;
	};
};

class Will : public Archive
{
	const static int CHECK_FILENAME_MAX = 32;

protected:
	int  m_extnum;
	int  m_fnlen;
	struct _EXT
	{
		char ext[4];
		unsigned long num;
		unsigned long addr;
	};
	vector<_EXT> m_ext;

public:
	Will(FILE *in);
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, 0x04 + sizeof(_EXT)*m_extnum, m_fnlen + m_copy_size, m_fnlen, m_copy_size);
	};
	virtual int analyze(int i);
};

Will::Will(FILE *in) : Archive(in)
{
	m_extnum = read();
	m_ext.reserve(m_extnum);
	fread(&m_ext[0], sizeof(_EXT), m_extnum, m_in);
	for (int i = 0; i < m_extnum; i++)
		m_num += m_ext[i].num;
	array();
	m_copy_size = 8;
	char buf[CHECK_FILENAME_MAX];
	fread(buf, CHECK_FILENAME_MAX, 1, m_in);
	m_fnlen = 0;
	while (buf[++m_fnlen]);
	while (!buf[++m_fnlen]);
	if (buf[m_fnlen*2+m_copy_size-1]) m_fnlen--;	// �}�ꗽ����size�̈ꌅ�ڂ�00�̏ꍇ�Ή�
	seek(0x04 + sizeof(_EXT)*m_extnum);
}

int Will::analyze(int i)
{
	if (over(i)) return false;
	int  num = 0;
	int  j;
	for (j = 0; j < m_extnum; j++)
	{
		num += m_ext[j].num;
		if (i < num)
			break;
	}
	char buf[CHECK_FILENAME_MAX];
	fread(buf, m_fnlen, 1, m_in);
	buf[m_fnlen] = 0;
	m_file[i].name = new char[m_fnlen+5];
	sprintf(m_file[i].name, "%s.%s", buf, m_ext[j].ext);
	m_file[i].pos = 0x04 + sizeof(_EXT)*m_extnum + i * (m_fnlen+m_copy_size) + m_fnlen;
	m_file[i].size = read();
	m_file[i].addr = read();
	return true;
}

class SParc : public Archive
{
protected:
	unsigned char m_mask[16];
	int  m_length;
	static const unsigned long HEADER = 0x08;
	static const unsigned long BLOCK = 0x2C;
	static const unsigned long IGNORE = 0x20;
	static const unsigned long COPY = 0x0C;

public:
	SParc(FILE *in);
	virtual void makedef(FILE *def, char *filename)
	{
		if (BLOCK % m_length == 0)
			makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
		else
			Archive::makedef(def, filename);
	};
	virtual int analyze(int i);
	virtual int process(int dest, int src, FILE *bak);
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
		if (m_file[i].orig != m_file[i].size)
		{
			seek(m_file[i].addr);
			unsigned char *buf = read(m_file[i].size);
			unsigned char *outbuf = new unsigned char[m_file[i].orig];
			lzdecode(outbuf, m_file[i].orig, buf, m_file[i].size);
			delete[] buf;
			FILE *out = makefile(outpath, m_file[i].name);
			if (out)
			{
				fwrite(outbuf, 1, m_file[i].orig, out);
				fclose(out);
			}
			delete[] outbuf;
			return true;
		}
		return Archive::extract(i, outpath);
	};
};

SParc::SParc(FILE *in) : Archive(in)
{
	readarray();
	m_length = 0;
	seek(HEADER + IGNORE - 0x08);
	fread(m_mask, 8, 1, m_in);
	seek(HEADER + BLOCK + IGNORE - 0x08);
	fread(m_mask+8, 8, 1, m_in);
	for (int i = 1; i < 8; i++)
	{
		if (m_mask[7] == m_mask[7-i])
		{
			if (m_mask[i] != m_mask[0])
				continue;
			m_length = i;
			break;
		}
	}
	if (!m_length)
		m_num = 0;
	else
	{
		seek(HEADER + IGNORE - 0x08);
		for (int i = 0; i < 8; i++)
			m_mask[(HEADER + IGNORE - 0x08 + i) % m_length] = read8();
	}
	m_copy_size = COPY;
};

int SParc::analyze(int i)
{
	if (over(i)) return false;
	seek(HEADER + i*BLOCK);
	unsigned char buf[BLOCK];
	fread(buf, BLOCK, 1, m_in);
	for (int j = 0; j < BLOCK; j++)
		buf[j] -= m_mask[(HEADER + i*BLOCK + j)%m_length];
	m_file[i].name = newcopy(buf);
	m_file[i].pos = HEADER + i*BLOCK + IGNORE;
	m_file[i].orig = *(long*)(buf+IGNORE);
	m_file[i].size = *(long*)(buf+IGNORE+4);
	m_file[i].addr = *(long*)(buf+IGNORE+8);
	return true;
}

int SParc::process(int dest, int src, FILE *bak)
{
	unsigned char buf[COPY];
	seek(m_file[dest].pos);
	fread(buf, COPY, 1, m_in);
	backup(m_file[dest].pos, buf, COPY, bak);
	seek(m_file[src].pos);
	fread(buf, COPY, 1, m_in);
	for (int i = 0; i < COPY; i++)
	{
		buf[i] -= m_mask[(m_file[src].pos + i) % m_length];
		buf[i] += m_mask[(m_file[dest].pos + i) % m_length];
	}
	seek(m_file[dest].pos);
	fwrite(buf, COPY, 1, m_in);
	return 0;
};

class EUROS : public Archive
{
protected:
	unsigned long m_current;
	unsigned long m_data;
	FILE *m_out;

public:
	EUROS(FILE *in) : Archive(in)
	{
		m_out = NULL;
		m_data = 0;
		readarray();
		m_current = 4;
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		Archive::makedef(def, filename);
		fprintf(def, "!%d,out.arc\n", 1);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_current);
		m_file[i].name = readstr();
		m_file[i].pos = m_current + strlen(m_file[i].name) + 1;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		if (i > 0)
			m_file[i-1].size = m_file[i].addr - m_file[i-1].addr;
		else
			m_data = m_file[i].addr;
		if (i == m_num-1)
		{
			seeke(0);
			unsigned long end = ftell(m_in);
			m_file[i].size = end - m_file[i].addr;
		}
		m_current = m_file[i].pos + 8;
		return true;
	};
	virtual int process(int dest, int src, FILE *bak)
	{
		if (!m_out) return false;
		fseek(m_out, m_file[dest].pos, SEEK_SET);
		fwrite(&m_current, 4, 1, m_out);
		fseek(m_out, m_current, SEEK_SET);
		copyfile(m_in, m_file[src].addr, m_file[src].size, m_out);
		m_current += m_file[src].size;
		return true;
	};
	virtual bool needbackup(){return false;};
	virtual void optionfile(FILE *fp)
	{
		FCLOSE(m_out);
		m_out = fp;
		fseek(m_out, 0, SEEK_SET);
		if (m_data)
		{
			seek(0);
			unsigned char *buf = read(m_data);
			fwrite(buf, 1, m_data, m_out);
			delete[] buf;
		}
		m_current = m_data;
	};
	virtual ~EUROS()
	{
		FCLOSE(m_out);
	};
};

class PNAP : public Archive
{
public:static const unsigned long SIGNATURE = 0x50414E50;

	static const unsigned long HEADER = 0x14;
	static const unsigned long BLOCK = 0x28;
	static const unsigned long IGNORE = 8;
protected:
	unsigned long m_current;
	FILE *m_out;

public:
	PNAP(FILE *in) : Archive(in)
	{
		m_out = NULL;
		seek(0x10);
		readarray();
		m_copy_size = 0x20;
		m_current = HEADER + m_num*BLOCK;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		Archive::makedef(def, filename);
		fprintf(def, "!%d,out.pna\n", 1);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].name = new char[64];
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		seek(m_file[i].pos);
		int  x = read();
		int  y = read();
		sprintf(m_file[i].name, "%.5d+x%dy%d.png", i, x, y);
		seekc(0x14);
		m_file[i].addr = m_current;
		m_file[i].size = read();
		m_current += m_file[i].size;
		return true;
	};
	virtual int process(int dest, int src, FILE *bak)
	{
		if (!m_out) return false;
		seek(m_file[src].pos);
		unsigned char *buf = read(m_copy_size);
		fseek(m_out, m_file[dest].pos, SEEK_SET);
		fwrite(buf, 1, m_copy_size, m_out);
		delete[] buf;
		fseek(m_out, m_current, SEEK_SET);
		copyfile(m_in, m_file[src].addr, m_file[src].size, m_out);
		m_current += m_file[src].size;
		return true;
	};
	virtual bool needbackup(){return false;};
	virtual void optionfile(FILE *fp)
	{
		FCLOSE(m_out);
		m_out = fp;
		seek(0);
		unsigned long size = HEADER + m_num*BLOCK;
		unsigned char *buf = read(size);
		fseek(m_out, 0, SEEK_SET);
		fwrite(buf, 1, size, m_out);
		m_current = size;
		delete[] buf;
	};
	virtual ~PNAP()
	{
		FCLOSE(m_out);
	};
};

class PULLTOP : public Archive
{
protected:
	static const unsigned long HEADER = 0x08;
	unsigned long m_data;
	unsigned long m_current;

public:
	PULLTOP(FILE *in) : Archive(in)
	{
		readarray();
		m_data = read() + HEADER;
		setlocale(LC_CTYPE, "");
		m_copy_size = 8;
		m_current = 8;
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_current);
		m_file[i].pos = m_current;
		m_file[i].size = read();
		m_file[i].addr = read() + m_data;
		unsigned char *buf = read(64);
		m_file[i].name = new char[64];
		int  len = wcstombs(m_file[i].name, (wchar_t*)buf, 64);
		m_file[i].name[len] = 0;
		len = mbstowcs((wchar_t*)buf, m_file[i].name, len);
		delete[] buf;
		m_current += 8 + len*2 + 2;
		return true;
	};
#ifdef EXTRACT_MODE
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		seek(m_file[i].addr);
		unsigned long sig = read();
		if (sig == PNAP::SIGNATURE)
		{
			seekc(0x0C);
			int  num = read();
			unsigned long current = m_file[i].addr + PNAP::HEADER + num*PNAP::BLOCK;
			for (int j = 0; j < num; j++)
			{
				seek(m_file[i].addr + PNAP::HEADER + j*PNAP::BLOCK + PNAP::IGNORE);
				int  x = read();
				int  y = read();
				char filename[BUFSIZE];
				int  len = strlen(m_file[i].name);
				char format[128];
				sprintf(format, "%%.%d%s", len-4, "s_%.5d+x%dy%d.png");
				sprintf(filename, format, m_file[i].name, j, x, y);
				seekc(0x14);
				unsigned long addr = current;
				unsigned long size = read();
				current += size;
				if (!size)
					continue;
				FILE *out = makefile(outpath, filename);
				if (out == NULL)
					continue;
				copyfile(m_in, addr, size, out);
				fclose(out);
			}
			return 1;
		}
		return extractB(i, outpath);
	};
#endif
};

class AI6WIN : public Archive
{
protected:
	static const unsigned long HEADER = 0x4;
	static const unsigned long BLOCK = 0x110;
	static const unsigned long IGNORE = 0x104;

public:
	AI6WIN(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 12;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i);
};

int AI6WIN::analyze(int i)
{
	if (over(i)) return false;
	seek(HEADER + i*BLOCK);
	m_file[i].name = read(IGNORE);
	int len = strlen(m_file[i].name);
	for (int j = 0; j < len; j++)
		m_file[i].name[j] += j - len - 1;
	m_file[i].pos = HEADER + i*BLOCK + IGNORE;
	m_file[i].size = endian(read());
	m_file[i].orig = endian(read());
	m_file[i].addr = endian(read());
	return true;
}

class RJ105184 : public Archive
{
public:static const unsigned long SIGNATURE = 0x00000064;

	protected:
	static const unsigned long HEADER = 0x10;
	unsigned long m_current;
	int  m_dirnum;

public:
	RJ105184(FILE *in) : Archive(in)
	{
		seek(8);
		m_dirnum = read();
		m_copy_size = 8;
		m_current = HEADER;
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_current);
		m_file[i].pos = m_current;
		m_file[i].addr = read();
		m_file[i].size = read();
		int  filenamesize = read8();
		m_file[i].name = read(filenamesize);
		m_current += 9 + filenamesize;
		checkcurrent();
		return true;
	};
	virtual int analyze_all();
	void readdir();
	void checkcurrent()
	{
		if (m_current % 0x10)
			m_current = (m_current / 0x10 + 1) * 0x10;
	}
};

int RJ105184::analyze_all()
{
	for (int i = 0; i < m_dirnum; i++)
		readdir();
	return 0;
};

void RJ105184::readdir()
{
	seek(m_current);
	int  num = read();
	int  dirnamesize = read8();
	char *dirname = read(dirnamesize);
	m_current += 4 + 1 + dirnamesize;
	checkcurrent();
	m_file.reserve(m_num + num);
	for (int j = 0; j < num; j++)
	{
		int i = extend();
		analyze(i);
		char *old = m_file[i].name;
		m_file[i].name = new char[dirnamesize + strlen(old) + 2];
		sprintf(m_file[i].name, "%s\\%s", dirname, old);
		delete[] old;
	}
};

class ARCFF : public Archive
{
public:static const unsigned long SIGNATURE = 0x000000FF;

protected:
	static const unsigned long HEADER = 0x10;
	unsigned long m_info;
	unsigned long m_block;
	unsigned long m_data;
	unsigned long m_type;
	unsigned char *m_mask;

public:
	ARCFF(FILE *in) : Archive(in)
	{
		m_block = read();
		int  num = read();
		readarray();
		m_info = num * m_block + 0x20E;
		seek(m_info);
		m_copy_size = read();
		m_data = m_info + read() * m_copy_size + 0x1C;
		m_info += 0x10;

		seek(m_info);
		unsigned long addr = read();
		unsigned long addr2 = read();
		seek(addr + m_data);
		unsigned long size = read();
		unsigned long size2 = addr2 - addr;
		if (abs(size2 - size) < 10)
			m_type = 1;
		else
			m_type = 2;

		m_mask = "\x09\xfb\x04\xfd\x82\x7e\xc1\x3f\x60\x9f\xb0\x4f\xd8\x27\xec\x13\xf6";
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, m_info, m_copy_size, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*m_block);
		m_file[i].name = read(m_block);
		seek(m_info + i*4);
		m_file[i].pos = m_info + i*4;
		m_file[i].addr = read() + m_data;
		seek(m_file[i].addr);
		if (m_type == 1)
		{
			m_file[i].size = read();
			m_file[i].addr += 4;
		}
		else if (m_type == 2)
		{
			seekc(12);
			m_file[i].size = read();
			m_file[i].addr += 10;
		}
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
		if (m_type == 1)
			return extractB(i, outpath);

		seek(m_file[i].addr);
		unsigned char *buf = read(m_file[i].size);
		FILE *out = makefile(outpath, m_file[i].name);
		if (out)
		{
			maskbuf(buf, m_file[i].size, m_mask, 0x11);
			fwrite(buf, 1, m_file[i].size, out);
			fclose(out);
		}
		delete[] buf;
		return true;
	}
};

class nanairo_r : public Archive
{
protected:
	static const unsigned long HEADER = 0x4;
	static const unsigned long BLOCK = 0x110;
	static const unsigned long IGNORE = 0x104;
	unsigned long m_infosize;
	unsigned long m_current;

public:
	nanairo_r(FILE *in) : Archive(in)
	{
		m_infosize = read();
		m_current = 4;
		m_copy_size = 12;
	};
	virtual int analyze_all();
	virtual int analyze(int i);
};

int nanairo_r::analyze(int i)
{
	int  size = read8();
	m_file[i].pos = m_current + 1 + size;
	m_current += 1 + size + 12;
	m_file[i].name = read(size);
	unsigned char mask = size;
	for (int j = 0; j < size; j++)
	{
		m_file[i].name[j] += mask--;
	}
	m_file[i].size = endian(read());
	m_file[i].orig = endian(read());
	m_file[i].addr = endian(read());
	return true;
}

int nanairo_r::analyze_all()
{
	while (m_current < m_infosize)
		analyze(extend());
	return 0;
}

const char *ARC::EXT = ".arc";

Archive* ARC::Check(FILE *in)
{
	int  num;
	fseek(in, 0x0C, SEEK_SET);
	fread(&num, 4, 1, in);
	if (num == 0)
		return new PULLTOP(in);

	fseek(in, 4, SEEK_SET);
	fread(&num, 4, 1, in);
	if (num < 0x100)
		return new SParc(in);

	fseek(in, (num & 0xFF) + 5, SEEK_SET);
	int  size, orig;
	fread(&size, 4, 1, in);
	fread(&orig, 4, 1, in);
	if (size == orig)
		return new nanairo_r(in);

	fseek(in, 0, SEEK_SET);
	fread(&num, 4, 1, in);
	for (int i = 0; i < num; i++)
	{
		fseek(in, 0x04 + i*0x0C + 3, SEEK_SET);
		int  c = fgetc(in);
		if (c != 0)
		{
			fseek(in, 0x100, SEEK_SET);
			fread(&num, 4, 1, in);
			if (num)
				return new EUROS(in);
			else
				return new AI6WIN(in);
		}
	}
	return new Will(in);
};
