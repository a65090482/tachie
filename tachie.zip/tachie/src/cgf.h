class CGF : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class CGFArchive : public Archive
{
protected:
	static const unsigned long HEADER = 0x04;
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x1C;

public:
	CGFArchive(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 4;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read();
		if (m_file[i].addr & 0x80000000)
		{
			m_file[i].addr &= 0x7FFFFFFF;
			m_file[i].addr += 0x10;
		}
		seek(m_file[i].addr);
		m_file[i].size = read();
		m_file[i].addr += 0x04;
		return true;
	};
};

const char *CGF::EXT = ".cgf";

Archive* CGF::Check(FILE *in)
{
	return new CGFArchive(in);
};
