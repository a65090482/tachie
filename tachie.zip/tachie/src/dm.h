class DM : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class DM_ARC : public Archive
{
protected:
	static const unsigned long HEADER = 0x04;
	static const unsigned long BLOCK = 0x2C;
	static const unsigned long IGNORE = 0x24;
	unsigned char m_filename_length;
	unsigned long m_data;

public:
	DM_ARC(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i);
};

int DM_ARC::analyze(int i)
{
	if (over(i)) return false;
	seek(HEADER + i*BLOCK);
	m_file[i].name = read(0x20);
	for (int j = 0; j < 0x20; j++)
		if (m_file[i].name[j] == 0 && m_file[i].name[j+1] != 0)
		{
			m_file[i].name[j] = '.';
			break;
		}
	seekc(4);
	m_file[i].pos = HEADER + i*BLOCK + IGNORE;
	m_file[i].size = read();
	m_file[i].addr = read();
	return true;
}

const char *DM::EXT = ".dm";

Archive* DM::Check(FILE *in)
{
	return new DM_ARC(in);
};
