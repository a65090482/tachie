class BALDRSKYZERO_TRIAL : public Archive
{
public:static const unsigned long SIGNATURE = 0x000103BE;

protected:
	static const unsigned long HEADER = 0x1D2A;

public:
	BALDRSKYZERO_TRIAL(FILE *in) : Archive(in)
	{
		array(1368);
		m_copy_size = 12;
		seek(HEADER);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		int  filenamesize = read8();
		m_file[i].name = read(filenamesize);
		m_file[i].pos = ftell(m_in);
		m_file[i].addr = read();
		seekc(4);
		m_file[i].size = read();
		seekc(0x12);
		return true;
	};
};

class BALDRSKYZERO: public Archive
{
public:static const unsigned long SIGNATURE = 0x0002EDA4;

protected:
	static const unsigned long HEADER = 0x4FCF;

public:
	BALDRSKYZERO(FILE *in) : Archive(in)
	{
		array(3961);
		m_copy_size = 12;
		seek(HEADER);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		int  filenamesize = read8();
		m_file[i].name = read(filenamesize);
		m_file[i].pos = ftell(m_in);
		m_file[i].addr = read();
		seekc(4);
		m_file[i].size = read();
		seekc(0x12);
		return true;
	};
};

class huffman
{
private:
	unsigned short m_table[0x200];
	int  m_table_current;
	unsigned char m_bit;
	unsigned long m_code;
	unsigned char *m_buf;
	unsigned long m_length;
	unsigned long m_current;
	unsigned long m_code_table[0x100];
	char m_code_length[0x100];
	forward(int n);
	short getbits(unsigned long n)
	{
		if (forward(n))
			return 0;
		n = m_code;
		m_code &= ~(0xFFFFFFFF << m_bit);
		return n >> m_bit;
	};
	short maketable()
	{
		if (getbits(1))
		{
			short temp = m_table_current++;
			m_table[temp - 0x100] = maketable();
			m_table[temp] = maketable();
			return temp;
		}
		return getbits(8);
	};
	putbits(int length, unsigned long bits);
	writetable(int n, unsigned long code, int length)
	{
		if (n >= 0x100)
		{
			putbits(1, 1);
			writetable(m_table[n-0x100], (code << 1) | 0, length+1);
			writetable(m_table[n], (code << 1) | 1, length+1);
			return 1;
		}
		else
		{
			putbits(1, 0);
			putbits(8, n);
			m_code_table[n] = code;
			m_code_length[n] = length;
			return 0;
		}
	};
	init()
	{
		m_table_current = 0x100;
		m_table[0] = 0;
		m_table[m_table_current] = 0;
		m_current = 0;
		m_length = 0;
		m_buf = NULL;
		m_bit = 0;
		m_code = 0;
		return 0;
	};
	huffman()
	{
		init();
	};

public:
	static decode(unsigned char*,int,unsigned char*,int);
	huffman(unsigned char *buf, unsigned long length)
	{
		init();
		m_buf = buf;
		m_length = length;
		maketable();
	};
	decode(unsigned char*,int);
	encode(unsigned char*,int,unsigned char*,int);
};

huffman::forward(int n)
{
	while (m_bit < n)
	{
		m_bit += 8;
		m_code <<= 8;
		if (m_current >= m_length)
			return true;
		m_code |= m_buf[m_current++];
	}
	m_bit -= n;
	return 0;
};

huffman::putbits(int length, unsigned long bits)
{
	for (int l = length; l-- > 0;)
	{
		if (m_current >= m_length)
			return 0;
		m_buf[m_current] &= (0xFE << m_bit);
		if (l >= m_bit)
		{
			m_buf[m_current] |= bits >> (l - m_bit);
			l -= m_bit;
			m_bit = 7;
			m_current++;
		}
		else
		{
			m_buf[m_current] |= (bits & ~(0xFFFFFFFE<<l)) << (m_bit - l);
			m_bit -= l+1;
			l = 0;
		}
	}
/*	for (int i = length-1; i >= 0; i--)
	{
		m_buf[m_current] &= 0xFE << m_bit;
		m_buf[m_current] |= ((bits >> i) & 1) << m_bit;
		if (m_bit-- == 0)
		{
			m_bit += 8;
			m_current++;
		}
	}*/
	return length;
};

huffman::decode(unsigned char *destBuffer, int destLength)
{
	for (int i = 0; i < destLength; i++)
	{
		short x = 0x100;
		while (x >= 0x100)
		{
			if (forward(1))
				return i;
			if (m_code >> m_bit)
				x = m_table[x];
			else
				x = m_table[x - 0x100];
			m_code &= ~(0xFF << m_bit);
		}
		if (i >= destLength)
			return i;
		destBuffer[i] = x;
	}
	return 0;
}

huffman::encode(unsigned char *srcBuffer, int srcLength, unsigned char *destBuffer, int destLength)
{
	m_bit = 7;
	m_current = 0;
	m_buf = destBuffer;
	m_length = destLength;
	writetable(0x100, 0, 0);
	for (int i = 0; i < srcLength; i++)
		if (!putbits(m_code_length[srcBuffer[i]], m_code_table[srcBuffer[i]]))
			break;
	return m_current+1;
};

huffman::decode(unsigned char *srcBuffer, int srcLength, unsigned char *destBuffer, int destLength)
{
	huffman huff;
	huff.m_buf = srcBuffer;
	huff.m_length = srcLength;
	huff.maketable();
	return huff.decode(destBuffer, destLength);
}

class GIGA : public Archive
{
	static const unsigned long SIGNATURE = 0x00434150;
	static const unsigned long BLOCK = 0x4C;
	static const unsigned long IGNORE = 0x40;

private:
	unsigned char *m_info;
	unsigned char *m_originfo;
	unsigned long m_originfosize;
	huffman *huff;
	FILE *m_backupfile;

public:
	GIGA(FILE *in) : Archive(in)
	{
		seek(0x04);
		readarray();
		seeke(4);
		m_originfosize = read();
		seeke(4 + m_originfosize);
		m_originfo = read(m_originfosize);
		maskbuf(m_originfo, m_originfosize, 0xFF);
		m_info = new unsigned char[m_num * BLOCK];
		huff = new huffman(m_originfo, m_originfosize);
		huff->decode(m_info, m_num * BLOCK);
		m_copy_size = 0;
		m_backupfile = NULL;
	};
	virtual analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].name = newcopy(&m_info[i*BLOCK]);
		m_file[i].pos = i*BLOCK + IGNORE;
		m_file[i].addr = *(unsigned long*)&m_info[i*BLOCK + IGNORE];
		m_file[i].size = *(unsigned long*)&m_info[i*BLOCK + IGNORE + 8];
		return true;
	};
	virtual process(int dest, int src, FILE *bak)
	{
		if (!m_backupfile && bak)
			m_backupfile = bak;
		memcpy(&m_info[m_file[dest].pos], &m_info[m_file[src].pos], 0x0C);
		return 0;
	};
	virtual ~GIGA()
	{
		if (m_backupfile)
		{
			unsigned char *buf = new unsigned char[m_originfosize + m_num*BLOCK];
			unsigned long l = huff->encode(m_info, m_num * BLOCK, buf, m_originfosize + m_num*BLOCK);
			maskbuf(buf, l, 0xFF);
			if (l > m_originfosize)
				seeke(4 + m_originfosize);
			else
				seeke(4 + l);
			fwrite(buf, 1, l, m_in);
			fwrite(&l, 4, 1, m_in);
			delete[] buf;

			seeke(0);
			int size = ftell(m_in);
			maskbuf(m_originfo, m_originfosize, 0xFF);
			backup(size-4-m_originfosize, m_originfo, m_originfosize, m_backupfile);
			backup(size-4, &m_originfosize, 4, m_backupfile);
		}
		delete[] m_info;
		delete[] m_originfo;
		delete huff;
	};
};
