class DAT : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class MinkDAT : public Archive
{
protected:
	static const unsigned long HEADER = 0x04;
	static const unsigned long BLOCK = 0x4C;
	static const unsigned long IGNORE = 0x44;

public:
	MinkDAT(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].size = read();
		m_file[i].addr = read();
		return true;
	};
};

class MeteorDAT : public Archive
{
protected:
	static const unsigned long COPY = 0x08;
	static const unsigned long MASK_LENGTH = 8;
	unsigned long m_header;
	unsigned long m_info;
	unsigned long m_block;
	unsigned char m_mask[MASK_LENGTH];

public:
	MeteorDAT(FILE *in);
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_header + m_info + i*m_block + 1);
		m_file[i].name = read(m_block-1);
		maskbuf(m_file[i].name, m_block-1, m_mask, MASK_LENGTH, m_header + m_info + i*m_block + 1);
		m_file[i].pos = m_header + m_info + i*m_block + m_block-12;
		m_file[i].addr = *(unsigned long*)(m_file[i].name + m_block-1-12) + m_header;
		m_file[i].size = *(unsigned long*)(m_file[i].name + m_block-1-8);
		return true;
	};
	virtual int extract(int i, char *outpath);
	virtual int process(int dest, int src, FILE *bak)
	{
		unsigned char buf[COPY];

		seek(m_file[dest].pos);
		fread(buf, COPY, 1, m_in);
		backup(m_file[dest].pos, buf, COPY, bak);

		seek(m_file[src].pos);
		fread(buf, COPY, 1, m_in);

		maskbuf(buf, COPY, m_mask, MASK_LENGTH, m_file[src].pos);
		maskbuf(buf, COPY, m_mask, MASK_LENGTH, m_file[dest].pos);

		seek(m_file[dest].pos);
		fwrite(buf, COPY, 1, m_in);
		return 0;
	};
};

MeteorDAT::MeteorDAT(FILE *in) : Archive(in)
{
	unsigned char buf[BUFSIZE];
	fread(buf, BUFSIZE, 1, m_in);
	for (int i = 0; i < BUFSIZE-8; i++)
	{
		if (buf[i] == 'C')
		{
			if (buf[i+1] == 'H' && buf[i+4] == 'E' && buf[i+5] == 0)
			{
				m_header = i-2;
				break;
			}
		}
	}
	if (m_header)
	{
		seek(m_header + 0x18);
		for (int i = 0; i < MASK_LENGTH; i++)
			m_mask[(m_header+0x18+i) % MASK_LENGTH] = read8();

		seek(m_header + 0x10);
		m_info = read();
		maskbuf(&m_info, 4, m_mask, MASK_LENGTH, m_header + 0x10);
		m_block = read();
		maskbuf(&m_block, 4, m_mask, MASK_LENGTH, m_header + 0x14);
		seek(m_header + 0x20);
		m_num = read();
		maskbuf(&m_num, 4, m_mask, MASK_LENGTH, m_header + 0x20);
		array();
		m_copy_size = COPY;
	}
}

int MeteorDAT::extract(int i, char *outpath)
{
	FILE *out = makefile(outpath, m_file[i].name);
	if (out == NULL)
		return false;

	unsigned char buf[BUFSIZE];
	seek(m_file[i].addr);
	int  j = 0;
	for (long rest = m_file[i].size; rest > 0; rest -= BUFSIZE)
	{
		int r = min((long)BUFSIZE, rest);
		fread(buf, r, 1, m_in);
		maskbuf(buf, r, m_mask, 8, m_file[i].addr + BUFSIZE*j);
		fwrite(buf, r, 1, out);
		j++;
	}

	fclose(out);
	return true;
};

class AIL : public Archive
{
protected:
	static const unsigned long HEADER = 0x04;
	static const unsigned long BLOCK = 0x04;
	unsigned long m_current;
	FILE *m_out;

public:
	AIL(FILE *in) : Archive(in)
	{
		m_out = NULL;
		readarray();
		m_current = HEADER + m_num*BLOCK;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		Archive::makedef(def, filename);
		fprintf(def, "!%d,out.dat\n", 1);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = HEADER + i*BLOCK;
		seek(m_file[i].pos);
		m_file[i].size = read();
		m_file[i].addr = m_current;
		m_file[i].name = new char[10];
		if (m_file[i].size == 0)
		{
			m_file[i].name[0] = 0;
			return true;
		}
		sprintf(m_file[i].name, "%.5d", i);
		m_current += m_file[i].size;
		seek(m_file[i].addr);
		unsigned short s = read16();
		if (s == 0x00)
			strcat(m_file[i].name, ".ogg");
		else if (s == 0x10 || s == 0x08)
			strcat(m_file[i].name, ".png");
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		if (!m_file[i].size) return false;
		seek(m_file[i].addr);
		unsigned short s = read16();
		if (s == 0x00)
		{
			m_file[i].addr += 4;
			m_file[i].size -= 4;
		}
		else if (s == 0x10 || s == 0x08)
		{
			m_file[i].addr += 6;
			m_file[i].size = read();
		}
		return Archive::extract(i, outpath);
	};
	virtual int process(int dest, int src, FILE *bak)
	{
		if (!m_out) return false;
		fseek(m_out, m_file[dest].pos, SEEK_SET);
		fwrite(&m_file[src].size, 4, 1, m_out);
		fseek(m_out, m_current, SEEK_SET);
		copyfile(m_in, m_file[src].addr, m_file[src].size, m_out);
		m_current += m_file[src].size;
		return true;
	};
	virtual bool needbackup(){return false;};
	virtual void optionfile(FILE *fp)
	{
		FCLOSE(m_out);
		m_out = fp;
		fseek(m_out, 0, SEEK_SET);
		fwrite(&m_num, 4, 1, m_out);
		m_current = HEADER + m_num*BLOCK;
	};
	virtual ~AIL()
	{
		FCLOSE(m_out);
	};
};

class BLACKRAINBOW : public Archive
{
protected:
	static const unsigned long HEADER = 0x10;
	static const unsigned long BLOCK = 0x4;
	unsigned long m_base;

public:
	BLACKRAINBOW(FILE *in) : Archive(in)
	{
		seek(8);
		readarray();
		m_base = read();
		m_copy_size = 4;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = HEADER + i*BLOCK;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		if (m_file[i].addr == 0xFFFFFFFF)
		{
			m_file[i].name = new char[2];
			m_file[i].name[0] = 0;
			m_file[i].size = 0;
			return true;
		}
		m_file[i].addr += m_base;
		seek(m_file[i].addr);
		m_file[i].name = read(0x20);
		m_file[i].size = read();
		m_file[i].addr += 0x24;
		return true;
	};
};

class arccDAT : public Archive
{
protected:
	static const unsigned long HEADER = 0x04;
	static const unsigned long BLOCK = 0x4C;
	static const unsigned long IGNORE = 0x44;
	unsigned long m_current;

public:
	arccDAT(FILE *in) : Archive(in)
	{
		m_current = 0;
	};
	virtual int analyze_all();
};

int arccDAT::analyze_all()
{
	while (1)
	{
		seek(m_current);
		unsigned long size = read();
		if (!size)
			break;
		int i = extend();
		m_file[i].size = size;
		seekc(4);
		size = read16();
		m_file[i].name = read(size);
		m_current += 8 + 2 + size;
		m_file[i].addr = m_current;
		m_current += m_file[i].size;
	}
	return 0;
}

class RJ086947 : public Archive
{
protected:
	static const unsigned long HEADER = 0x20;
	static const unsigned long BLOCK = 0x110;
	static const unsigned long IGNORE = 0x100;

public:
	RJ086947(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].size = read();
		m_file[i].addr = read();
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
		seek(m_file[i].addr);
		unsigned long sig = read();
		if (sig == 0x504D4341 || sig == 0x30535250)
		{
			seek(m_file[i].addr+0x10);
			m_file[i].orig = read();
			m_file[i].size = read();
			seek(m_file[i].addr+0x24);
			unsigned char *buf = read(m_file[i].size);
			unsigned char *outbuf = new unsigned char[m_file[i].orig];
			lzdecode(outbuf, m_file[i].orig, buf, m_file[i].size);
			delete[] buf;
			FILE *out = makefile(outpath, m_file[i].name);
			if (out)
			{
				fwrite(outbuf, 1, m_file[i].orig, out);
				fclose(out);
			}
			delete[] outbuf;
			return true;
		}
		return Archive::extract(i, outpath);
	};
};

class RJ086947_sound : public Archive
{
protected:
	static const unsigned long HEADER = 0x4;
	static const unsigned long BLOCK = 0x104;
	static const unsigned long IGNORE = 0x100;
	unsigned long m_current;

public:
	RJ086947_sound(FILE *in) : Archive(in)
	{
		readarray();
		m_current = HEADER;
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_current);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = m_current + IGNORE;
		m_file[i].size = read();
		m_file[i].addr = m_current + BLOCK;
		m_current += BLOCK + m_file[i].size;
		return true;
	};
};

class RJ086947_voice : public Archive
{
protected:
	static const unsigned long HEADER = 0x8;
	static const unsigned long BLOCK = 0x108;
	static const unsigned long IGNORE = 0x100;
	unsigned long m_data;

public:
	RJ086947_voice(FILE *in) : Archive(in)
	{
		m_data = read();
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].size = read();
		m_file[i].addr = read();
		return true;
	};
};

class RJ144981 : public Archive
{
public:
	RJ144981(FILE *in) : Archive(in)
	{
	};
	virtual int analyze_all();
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		int  size = read();
		m_file[i].name = readwc(size);
		m_file[i].size = read();
		m_file[i].addr = ftell(m_in);
		seekc(m_file[i].size);
		return true;
	};
	virtual int extract(int i, char *outpath)
	{
		return extractB(i, outpath, 0x95);
	};
};

int RJ144981::analyze_all()
{
	while (read() && !feof(m_in))
	{
		seekc(-4);
		int  i = extend();
		analyze(i);
	}
	return 0;
}

const char *DAT::EXT = ".dat";

Archive* DAT::Check(FILE *in)
{

	printf("0:Auto Detect\n");
	printf("1:Mink\n");
	printf("2:Meteor\n");
	printf("3:Actress ACTGS\n");
	printf("4:Waffle\n");
	printf("5:AIL\n");
	printf("6:BLACKRAINBOW\n");
	printf("7:arcc.dat\n");
	printf("8:RJ086947\n");
	printf("9:RJ086947_sound\n");
	printf("10:RJ086947_voice\n");
	printf("11:RJ144981\n");
	printf("select:");
	int select = gets_int();
	switch (select)
	{
	case 1:	return new MinkDAT(in);
	case 2:	return new MeteorDAT(in);
	case 3:	return new ACTGS(in);
	case 4:	return new WaffleDAT(in);
	case 5:	return new AIL(in);
	case 6:	return new BLACKRAINBOW(in);
	case 7:	return new arccDAT(in);
	case 8:	return new RJ086947(in);
	case 9:	return new RJ086947_sound(in);
	case 10:return new RJ086947_voice(in);
	case 11:return new RJ144981(in);
	}

	fseek(in, 0, SEEK_END);
	unsigned long size = ftell(in);
	unsigned char buf[0x0C];
	fseek(in, 4, SEEK_SET);
	fread(buf, 0x0C, 1, in);
	for (int i = 0; i < 0x0C; i++)
	{
		if (buf[i])
		{
			{
				unsigned long num;
				fseek(in, 0, SEEK_SET);
				fread(&num, 4, 1, in);
				if (num*4 + 4 < size)
				{
					unsigned short s;
					unsigned long l;
					fseek(in, num*4 + 4, SEEK_SET);
					fread(&s, 2, 1, in);
					fread(&l, 4, 1, in);
					if ((s == 0x10 || s == 0) && l)
						return new AIL(in);
				}
			}

			fseek(in, 0x40, SEEK_SET);
			fread(buf, 0x08, 1, in);
			for (int i = 0; i < 0x08; i++)
				if (buf[i])
					return new MeteorDAT(in);

			fread(buf, 0x08, 1, in);
			for (int i = 0; i < 0x08; i++)
				if (buf[i])
					return new MinkDAT(in);
			return new WaffleDAT(in);
		}
	}
	return new ACTGS(in);
};
