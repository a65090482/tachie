class S4IC : public Archive
{
public:static const unsigned long SIGNATURE = 0x43493453;

protected:
	static const unsigned long HEADER = 0x138;
	static const unsigned long BLOCK = 0x50;
	static const unsigned long IGNORE = 0x40;
	unsigned char *m_info;
	unsigned long m_header;
	FILE *m_out;

public:
	S4IC(FILE *in) : Archive(in)
	{
		seek(0x130);
		unsigned long orig = read();
		unsigned long size = read();
		unsigned char *buf = read(size);

		if (orig != size)
		{
			m_info = new unsigned char[orig];
			lzdecode(m_info, orig, buf, size);
			delete[] buf;
		}
		else
			m_info = buf;

		int  arcnum = *(unsigned long*)m_info;
		array(*(unsigned long*)(m_info + 4 + 0x100 * arcnum));
		m_header = 4 + 0x100 * arcnum + 4;
		m_copy_size = 16;

		m_out = NULL;
	};
	virtual ~S4IC()
	{
		if (m_out)
		{
			seek(0);
			unsigned char *head = read(0x130);
			unsigned long orig = read();
			fwrite(head, 1, 0x130, m_out);
			fwrite(&orig, 4, 1, m_out);
			fwrite(&orig, 4, 1, m_out);
			fwrite(m_info, 1, orig, m_out);
			delete[] head;
			fclose(m_out);
		}
		delete[] m_info;
	}
	virtual void makedef(FILE *def, char *filename)
	{
		Archive::makedef(def, filename);
		fprintf(def, "!%d,OUT.BIN\n", 1);
		makedefB(def, "OUT.BIN", HEADER + m_header, BLOCK, IGNORE, m_copy_size);
	};
	virtual void optionfile(FILE *fp)
	{
		fseek(fp, 0, SEEK_SET);
		if (!m_out)
		{
			m_out = fp;
		}
	};
	virtual bool needbackup(){return false;};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].name = newcopy(m_info + m_header + i*BLOCK);
		m_file[i].pos = m_header + i*BLOCK + IGNORE;
		m_file[i].orig = *(unsigned long*)(m_info + m_file[i].pos);
		m_file[i].addr = *(unsigned long*)(m_info + m_file[i].pos + 8);
		m_file[i].size = *(unsigned long*)(m_info + m_file[i].pos + 12);
		return true;
	};
};
