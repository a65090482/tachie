class CG : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class ACTGS : public Archive
{
protected:
	int  m_mask_length;
	unsigned char m_mask[0x10];
	static const unsigned long HEADER = 0x10;
	static const unsigned long BLOCK = 0x20;
	static const unsigned long COPY = 0x08;

public:
	ACTGS(FILE *in);
	virtual int analyze(int i)
	{
		if (over(i)) return false;

		m_file[i].pos = HEADER + i*BLOCK;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		maskbuf(&m_file[i].addr, 4, m_mask, m_mask_length, m_file[i].pos);
		m_file[i].size = read();
		maskbuf(&m_file[i].size, 4, m_mask, m_mask_length, m_file[i].pos + 4);
		m_file[i].name = read(0x18);
		maskbuf(m_file[i].name, 0x18, m_mask, m_mask_length, m_file[i].pos + 8);
		return true;
	};
	virtual int extract(int i, char *outpath);
	virtual int process(int dest, int src, FILE *bak)
	{
		unsigned char buf[COPY];

		seek(m_file[dest].pos);
		fread(buf, COPY, 1, m_in);
		backup(m_file[dest].pos, buf, COPY, bak);

		seek(m_file[src].pos);
		fread(buf, COPY, 1, m_in);

		maskbuf(buf, COPY, m_mask, m_mask_length, m_file[src].pos);
		maskbuf(buf, COPY, m_mask, m_mask_length, m_file[dest].pos);

		seek(m_file[dest].pos);
		fwrite(buf, COPY, 1, m_in);
		return 0;
	};
};

ACTGS::ACTGS(FILE *in) : Archive(in)
{
	readarray();

	m_mask_length = 0;
	seek(HEADER + 0x18);
	fread(m_mask, 8, 1, m_in);
	for (int i = 1; i < 8; i++)
	{
		if (m_mask[7] == m_mask[7-i])
		{
			m_mask_length = i;
			break;
		}
	}
	if (!m_mask_length)
	{
		seek(HEADER + BLOCK + 0x18);
		fread(m_mask+8, 8, 1, m_in);
		for (int i = 8; i < 16; i++)
		{
			if (m_mask[0] == m_mask[8+0]) m_mask_length = 8;
			else if (m_mask[7] == m_mask[8+2]) m_mask_length = 9;
			else if (m_mask[0] == m_mask[8+1]) m_mask_length = 11;
			else if (m_mask[0] == m_mask[8+4]) m_mask_length = 12;
			else if (m_mask[0] == m_mask[8+7]) m_mask_length = 13;
			else if (m_mask[4] == m_mask[8+0]) m_mask_length = 14;

			else if (m_mask[2] == m_mask[8+0])
			{
				seek(HEADER + BLOCK*2 + 0x1E);
				fread(m_mask+1, 1, 1, m_in);
				if (m_mask[0] == m_mask[1])
					m_mask_length = 10;
				else
					m_mask_length = 15;
			}
		}
	}
	if (!m_mask_length) return;
	for (int i = 0; i < 7; i++)
	{
		seek(HEADER + i*BLOCK + 0x18);
		for (int j = 0; j < 8; j++)
			m_mask[(HEADER + i*BLOCK + 0x18+j) % m_mask_length] = read8();
	}
	m_copy_size = COPY;
};

int ACTGS::extract(int i, char *outpath)
{
	if (over(i)) return false;
	if (!m_file[i].size) return false;
	FILE *out = makefile(outpath, m_file[i].name);
	if (out == NULL)
		return false;

	bool head = true;
	unsigned char buf[BUFSIZE];
	seek(m_file[i].addr);
	for (long rest = m_file[i].size; rest > 0; rest -= BUFSIZE)
	{
		int r = min((long)BUFSIZE, rest);
		fread(buf, r, 1, m_in);
		if (head)
		{
			maskbuf(buf, 0x20, m_mask, m_mask_length, HEADER);
			head = false;
		}
		fwrite(buf, r, 1, out);
	}

	fclose(out);
	return true;
};

const char *CG::EXT = ".cg";

Archive* CG::Check(FILE *in)
{
	return new ACTGS(in);
};
