class AOS : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class AOSArchive : public Archive
{
protected:
	static const unsigned long HEADER = 0x111;
	static const unsigned long BLOCK = 0x28;
	static const unsigned long IGNORE = 0x20;
	unsigned long m_data;

public:
	AOSArchive(FILE *in) : Archive(in)
	{
		seek(0x04);
		m_data = read();
		m_num = read() / BLOCK;
		array();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = HEADER + i*BLOCK + IGNORE;
		m_file[i].addr = read() + m_data;
		m_file[i].size = read();
		return true;
	};
};

class OLD_AOSArchive : public Archive
{
protected:
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x10;

public:
	OLD_AOSArchive(FILE *in) : Archive(in)
	{
		m_copy_size = 8;
	};
	virtual int analyze_all();
	virtual int process(int dest, int src, FILE *bak)
	{
		unsigned long buf[2];

		seek(m_file[dest].pos);
		fread(buf, 4, 2, m_in);
		backup(m_file[dest].pos, buf, 8, bak);

		seek(m_file[src].pos);
		fread(buf, 4, 2, m_in);

		buf[0] += (m_file[src].pos - m_file[dest].pos);

		seek(m_file[dest].pos);
		fwrite(buf, 4, 2, m_in);
		return 0;
	};
};

int OLD_AOSArchive::analyze_all()
{
	unsigned long buf[8];
	unsigned long current = 0;
	while (fread(buf, 4, 8, m_in))
	{
		unsigned long pos = current + IGNORE;
		current += BLOCK;
		if (buf[0] == 0xFFFFFFFF)
		{
			seekc(buf[4]);
			current += buf[4];
			continue;
		}
		else if (buf[0] == 0)
		{
			break;
		}
		int i = extend();
		m_file[i].pos = pos;
		m_file[i].name = newcopy((char*)buf);
		m_file[i].addr = (int)buf[4] + current;
		m_file[i].size = buf[5];
	}
	return 0;
}

const char *AOS::EXT = ".aos";

Archive* AOS::Check(FILE *in)
{
	fseek(in, 0, SEEK_SET);
	unsigned long sig;
	fread(&sig, 4, 1, in);

	if (sig == 0)
		return new AOSArchive(in);
	else
		return new OLD_AOSArchive(in);
};
