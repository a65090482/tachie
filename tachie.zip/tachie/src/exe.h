class EXE : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class vff : public Archive
{
public:static const unsigned long SIGNATURE = 0x00666676;

protected:
	static const unsigned long BLOCK = 0x20;
	static const unsigned long IGNORE = 0x10;
	unsigned long m_header;
	unsigned __int64 m_key;
	unsigned __int64 update(unsigned long seed)
	{
		m_key = (m_key << 2) + m_key + seed;
		return m_key;
	}

public:
	vff(FILE *in, unsigned long header = 0) : Archive(in)
	{
		m_key = 0;
		m_header = header;
		seek(m_header + 0x06);
		readarray();
	};
	virtual int analyze_all();
	virtual int analyze(int i);
#ifdef ZLIB_H__
	virtual int extract(int i, char *outpath)
	{
		if (over(i)) return false;
		if (!m_file[i].size) return false;
		if (m_file[i].orig)
		{
			seek(m_file[i].addr);
			unsigned char *buf = read(m_file[i].size);
			unsigned long outsize = m_file[i].size * 10;
			unsigned char *outbuf = new unsigned char[outsize];
			uncompress(outbuf, &outsize, buf, m_file[i].size);
			delete[] buf;
			FILE *out = makefile(outpath, m_file[i].name);
			if (out)
			{
				fwrite(outbuf, 1, outsize, out);
				fclose(out);
			}
			delete[] outbuf;
			return true;
		}
		FILE *out = makefile(outpath, m_file[i].name);
		if (out == NULL)
			return false;
		copyfile(m_in, m_file[i].addr, m_file[i].size, out);
		fclose(out);
		return true;
	};
#endif
};

int vff::analyze_all()
{
	for (int i = 0; i < m_num; i++)
		analyze(i);
	m_key = 0;
	for (int i = 0; i < m_num; i++)
	{
		m_file[i].addr = (read() ^ update(0x75d6ee39)) + m_header;
		m_file[i].orig = read();
		if (i > 0)
			m_file[i-1].size = m_file[i].addr - m_file[i-1].addr;
	}
	m_file[m_num-1].size = (read() ^ update(0x75d6ee39)) + m_header - m_file[m_num-1].addr;
	read();
	for (int i = 0; i < m_num; i++)
	{
		m_file[i].orig = read8();
	}
	for (int i = 0; i < m_num; i++)
	{
		read();
	}
	for (int i = 0; i < m_num; i++)
	{
		read();
	}
	for (int i = 0; i < m_num; i++)
	{
		read8();
	}
	return 0;
}

int vff::analyze(int i)
{
	if (over(i)) return false;
	int  size = read();
	m_file[i].name = read(size);
	for (int j = 0; j < size; j++)
		m_file[i].name[j] ^= update(0x75d6ee39);
	m_file[i].size = 0;
	return true;
}

const char *EXE::EXT = ".exe";

Archive* EXE::Check(FILE *in)
{
	fseek(in, -0x10, SEEK_END);
	unsigned long sig;
	fread(&sig, 4, 1, in);
	if (sig == 0x20616666)
	{
		unsigned long header;
		unsigned long size;
		unsigned long data;
		fseek(in, -0x28, SEEK_END);
		fread(&data, 4, 1, in);
		fseek(in, 4, SEEK_CUR);
		if (!data)
		{
			fread(&data, 4, 1, in);
			fseek(in, 4, SEEK_CUR);
			fread(&header, 4, 1, in);
			fread(&size, 4, 1, in);
			return new BLACKPACKAGE2(in, header, size, data);
		}
		fread(&header, 4, 1, in);
		fread(&size, 4, 1, in);
		return new BLACKPACKAGE(in, header, size, data);
	}

	fseek(in, 0x3C, SEEK_SET);
	unsigned long addres;
	fread(&addres, 4, 1, in);
	fseek(in, addres + 0x1C, SEEK_SET);
	unsigned long SizeOfCode;
	fread(&SizeOfCode, 4, 1, in);
	unsigned long SizeOfInitializedData;
	fread(&SizeOfInitializedData, 4, 1, in);
	fseek(in, addres + 0x54, SEEK_SET);
	unsigned long SizeOfHeaders;
	fread(&SizeOfHeaders, 4, 1, in);
	fseek(in, SizeOfHeaders + SizeOfCode + SizeOfInitializedData, SEEK_SET);
	fread(&sig, 4, 1, in);
	if (sig == vff::SIGNATURE)
		return new vff(in, SizeOfHeaders + SizeOfCode + SizeOfInitializedData);

	if (sig == 0x52455359)
	{
		fread(&sig, 4, 1, in);
		return new ypf(in, SizeOfHeaders + SizeOfCode + SizeOfInitializedData + sig);
	}

	fseek(in, SizeOfHeaders + SizeOfCode, SEEK_SET);
	for (int i = 0; i < (int)SizeOfInitializedData; i += 4)
	{
		fread(&sig, 4, 1, in);
		if (sig == XP3::SIGNATURE)
		{
			fread(&sig, 4, 1, in);
			if (sig == 0x1A0A200A)
			{
				fread(&sig, 4, 1, in);
				sig &= 0x00FFFFFF;
				if (sig == 0x0001678B)
					return new XP3(in, SizeOfHeaders + SizeOfCode + i);
			}
			fseek(in, SizeOfHeaders + SizeOfCode + i + 4, SEEK_SET);
		}
	}

	printf("%X,%X,%X\n", SizeOfHeaders, SizeOfCode, SizeOfInitializedData);
	return NULL;
};
