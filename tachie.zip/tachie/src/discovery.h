class PB : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class DiscoveryPB : public Archive
{
protected:
	static const unsigned long HEADER = 0x08;
	static const unsigned long BLOCK = 0x08;
	static const char *ext[];

public:
	DiscoveryPB(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 8;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		m_file[i].pos = HEADER + i*BLOCK;
		seek(m_file[i].pos);
		m_file[i].addr = read();
		m_file[i].size = read();
		m_file[i].name = new char[10];
		if (m_file[i].size)
		{
			int  e = 0;
			seek(m_file[i].addr);
			unsigned long sig = read();
			if (sig == 0x46464952)
				e = 1;
			sprintf(m_file[i].name, "%.5d%s", i, ext[e]);
		}
		else
			m_file[i].name[0] = 0;
		return true;
	};
};
const char *DiscoveryPB::ext[] = {"", ".wav"};

const char *PB::EXT = ".pb";

Archive* PB::Check(FILE *in)
{
	return new DiscoveryPB(in);
};
