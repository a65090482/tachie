class DAI : public Archive
{
public:static const unsigned long SIGNATURE = 0x5F494144;

protected:
	static const unsigned long HEADER = 0x16;
	void decode(unsigned char *buf, int begin, int max);
	void encode(unsigned char *buf, int begin, int max);
	unsigned long m_infosize;
	unsigned long m_current;
	FILE *m_out;

public:
	DAI(FILE *in) : Archive(in)
	{
		m_out = NULL;
		m_current = 0;
		seek(0x10);
		array(endian(read16(), 2));
		m_infosize = endian(read());
		m_copy_size = 4;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		Archive::makedef(def, filename);
		fprintf(def, "!%d,out.pac\n", 1);
	};
	virtual int analyze_all();
	virtual int process(int dest, int src, FILE *bak)
	{
		if (!m_out) return false;
		fseek(m_out, HEADER + m_file[dest].pos, SEEK_SET);
		unsigned long data = endian(m_current);
		encode((unsigned char*)&data, m_file[dest].pos, m_file[dest].pos + 4);
		fwrite(&data, 4, 1, m_out);
		fseek(m_out, m_current, SEEK_SET);
		seek(m_file[src].addr);
		unsigned char *buf = read(m_file[src].size);
		fwrite(buf, 1, m_file[src].size, m_out);
		m_current += m_file[src].size;
		delete[] buf;
		return 0;
	};
	virtual bool needbackup(){return false;};
	virtual void optionfile(FILE *fp)
	{
		FCLOSE(m_out);
		m_out = fp;
		fseek(m_out, 0, SEEK_SET);
		seek(0);
		m_current = HEADER + m_infosize;
		unsigned char *buf = read(m_current);
		fwrite(buf, 1, m_current, m_out);
		delete[] buf;
	};
	virtual ~DAI()
	{
		FCLOSE(m_out);
	};
};

void DAI::decode(unsigned char *buf, int begin, int max)
{
	for (int i = begin; i < max; i++)
		*(buf++) += 0xD8 - i;
};
void DAI::encode(unsigned char *buf, int begin, int max)
{
	for (int i = begin; i < max; i++)
		*(buf++) -= 0xD8 - i;
};

int DAI::analyze_all()
{
	seek(HEADER);
	unsigned char *buf = read(m_infosize);
	decode(buf, 0, m_infosize);
	unsigned long cur = 0;
	int  n = 0;
	while (cur < m_infosize)
	{
		char *c = buf + cur;
		while (*c != ',')
			c++;
		*c = 0;
		m_file[n].name = newcopy(buf + cur);
		m_file[n].pos = (c - buf) + 1;
		m_file[n].addr = endian(*(unsigned long*)(c+1));
		if (n > 0)
			m_file[n-1].size = m_file[n].addr - m_file[n-1].addr;
		cur = (c - buf) + 1 + 4 + 1;
		n++;
	}
	seeke(0);
	m_file[n-1].size = ftell(m_in) - m_file[n-1].addr;
	delete[] buf;
	return 0;
}
