class AWF : public Archive
{
public:static const unsigned long SIGNATURE = 0x46574131;

protected:
	static const unsigned long BLOCK = 0x40;
	static const unsigned long IGNORE = 4;
	unsigned long m_header;
	int child(unsigned long base, const char *path);

public:
	AWF(FILE *in) : Archive(in)
	{
		m_copy_size = 8;
	};
	virtual int analyze_all()
	{
		child(0, "");
		return 0;
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_header + i*BLOCK + IGNORE);
		m_file[i].pos = m_header + i*BLOCK + IGNORE;
		m_file[i].addr = read();
		m_file[i].size = read();
		seekc(4);
		m_file[i].name = read(0x30);
		return true;
	};
};

int AWF::child(unsigned long base, const char *path)
{
	seek(base + 0x0C);
	int  num = read();
	m_file.reserve(m_num + num);
	unsigned long header = base + read() + num*4;;
	for (int i = 0; i < num; i++)
	{
		seek(header + i*BLOCK + IGNORE);
		int  n = extend();
		m_file[n].pos = header + i*BLOCK + IGNORE;
		m_file[n].addr = read() + base;
		m_file[n].size = read();
		seekc(4);
		char *name = read(0x30);
		string npath;
		if (strlen(path))
		{
			npath = path;
			npath += "\\";
			npath += name;
		}
		else
			npath = name;
		m_file[n].name = newcopy(npath.c_str());
		seek(m_file[n].addr);
		unsigned long sig = read();
		if (sig == SIGNATURE)
		{
			m_file[n].size = 0;
			int len = npath.size();
			if (npath[len-4] == '.')
				npath[len-4] = 0;
			child(m_file[n].addr, npath.c_str());
		}
		delete[] name;
	}
	return num;
}
