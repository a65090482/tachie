class AOD : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class AOD_ARCHIVE : public Archive
{
protected:
	static const unsigned long BLOCK = 0x40;
	static const unsigned long IGNORE = 0x28;

public:
	AOD_ARCHIVE(FILE *in) : Archive(in)
	{
		m_copy_size = 8;
	};
/*	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, 0, BLOCK, IGNORE, m_copy_size);
	};*/
	virtual int analyze_all();
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(i*BLOCK);
		m_file[i].name = read(IGNORE);
		m_file[i].pos = i*BLOCK + IGNORE;
		m_file[i].addr = read() + (i+1) * BLOCK;
		m_file[i].size = read();
		return true;
	};
	virtual int process(int dest, int src, FILE *bak)
	{
		copyblock(m_in, m_file[dest].pos, m_file[src].pos, m_copy_size, bak);
		seek(m_file[dest].pos);
		unsigned long addr = m_file[src].addr - (dest+1)*BLOCK;
		fwrite(&addr, 1, 4, m_in);
		return 0;
	};
};

int AOD_ARCHIVE::analyze_all()
{
	unsigned long l = read();
	while (l != 0xFFFFFFFF)
	{
		analyze(extend());
		seek(m_num * BLOCK);
		l = read();
	}
	return 0;
}

const char *AOD::EXT = ".aod";

Archive* AOD::Check(FILE *in)
{
	return new AOD_ARCHIVE(in);
};
