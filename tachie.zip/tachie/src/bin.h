class BIN : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in);
};

class Favorite : public Archive
{
protected:
	unsigned long m_base;
	static const unsigned long HEADER = 0x08;
	static const unsigned long BLOCK = 0x0C;
	static const unsigned long IGNORE = 0x04;

public:
	Favorite(FILE *in) : Archive(in)
	{
		readarray();
		m_copy_size = 8;
		m_base = HEADER + m_num*BLOCK;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		makedefB(def, filename, HEADER, BLOCK, IGNORE, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(HEADER + i*BLOCK);
		int  filenameaddr = read();
		m_file[i].addr = read();
		m_file[i].size = read();

		seek(filenameaddr + m_base);
		m_file[i].name = read(64);
		m_file[i].pos = HEADER + i*BLOCK;
		return true;
	};
};

const char *BIN::EXT = ".bin";

Archive* BIN::Check(FILE *in)
{
	return new Favorite(in);
};
