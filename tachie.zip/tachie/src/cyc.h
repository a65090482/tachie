class CYC : public Archive
{
protected:
	FILE *m_gpk;
	FILE *m_gtb;

public:
	CYC(FILE *in);
	CYC(FILE *in, FILE *gpk = NULL, FILE *gtb = NULL) : Archive(in)
	{
		m_gpk = gpk;
		m_gtb = gtb;
		if (!m_gpk && !m_gtb)
			m_gtb = m_in;
		fseek(m_gtb, 0, SEEK_SET);
		fread(&m_num, 4, 1, m_gtb);
		array();
		m_copy_size = 4;
	};
	virtual void makedef(FILE *def, char *filename)
	{
		if (m_in != m_gtb)
		{
			char *openpath = newcopy(filename);
			int  length = strlen(filename);
			strncpy(openpath + length - EXT_SIZE, ".gtb", EXT_SIZE);
			fprintf(def, "@%d,0,%s\n", VERSION, openpath);
			delete[] openpath;
		}
		else
			fprintf(def, "@%d,0,%s\n", VERSION, filename);
		fprintf(def, "?%d,%d,%d,%d\n", 4 + m_num*4, 4, 0, m_copy_size);
	};
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		FILE *in_backup = m_in;
		m_in = m_gtb;

		seek(4 + i*4);
		int  filename = read();
		seek(4 + m_num*4 + i*4);
		m_file[i].pos = 4 + m_num*4 + i*4;
		m_file[i].addr = read();
		seek(4 + m_num*8 + filename);
		m_file[i].name = readstr();

		if (m_gpk)
		{
			m_in = m_gpk;
			seek(m_file[i].addr + 0x20);
			m_file[i].size = read();
			seekc(0x15);
			unsigned long packtype = read();

			int  length = strlen(m_file[i].name) + 5;
			char *newbuf = new char[length];
			if (m_file[i].size == 0x20202020)
			{
				seekc(5);
				m_file[i].size = read();
				sprintf(newbuf, "%s.bmp", m_file[i].name);
			}
			else if (packtype == 0x20204138)
				sprintf(newbuf, "%s.png", m_file[i].name);
			else if (packtype == 0x20204137)
				sprintf(newbuf, "%s.jpg", m_file[i].name);
			else if (packtype == 0x20202036)
				sprintf(newbuf, "%s.ogg", m_file[i].name);
			else if (packtype == 0x20202035)
				sprintf(newbuf, "%s.jpg", m_file[i].name);
			else if (packtype == 0x20202032)
			{
				sprintf(newbuf, "%s.ogg", m_file[i].name);
				m_file[i].addr += 0x2C;
			}
			else if (packtype == 0x20202030)
				sprintf(newbuf, "%s.wav", m_file[i].name);
			else
				sprintf(newbuf, "%s", m_file[i].name);
			delete[] m_file[i].name;
			m_file[i].name = newbuf;
			m_file[i].addr += 0x40;
		}

		m_in = in_backup;
		return true;
	};
	virtual ~CYC()
	{
		if (m_gtb != m_in) FCLOSE(m_gtb);
		if (m_gpk != m_in) FCLOSE(m_gpk);
	};
};

class GPK : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in, char *path)
	{
		Archive *arc = NULL;
		FILE *fp;
		char *openpath = newcopy(path);
		int  length = strlen(path);
		strncpy(openpath + length - EXT_SIZE, ".gtb", EXT_SIZE);
		if ((fp = fopen(openpath, "rb")) == NULL)
		{
			arc = new UMe(in);
//			printf("ERROR:cannot open arc file. %s\n", openpath);
		}
		else
			arc = new CYC(in, in, fp);
		delete[] openpath;
		return arc;
	};
};

class GTB : public ExtCheck
{
public:
	static const char *EXT;
	static Archive* Check(FILE *in, char *path)
	{
		Archive *arc = NULL;
		FILE *fp;
		char *openpath = newcopy(path);
		int  length = strlen(path);
		strncpy(openpath + length - EXT_SIZE, ".gpk", EXT_SIZE);
		if ((fp = fopen(openpath, "rb")) == NULL)
			printf("ERROR:cannot open arc file. %s\n", openpath);
		else
			arc = new CYC(in, fp, in);
		delete[] openpath;
		return arc;
	};
};

const char *GPK::EXT = ".gpk";
const char *GTB::EXT = ".gtb";
/*
const char *VPK::EXT = ".vpk";
const char *VTB::EXT = ".vtb";
const char *VAW::EXT = ".vaw";
const char *WGQ::EXT = ".wgq";
*/