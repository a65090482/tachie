class ARCFORM : public Archive
{
public:static const unsigned long SIGNATURE = 0x46435241;

protected:
	unsigned long m_current;

public:
	ARCFORM(FILE *in);
	virtual int analyze(int i)
	{
		if (over(i)) return false;
		seek(m_current);
		seekc(4);
		m_file[i].pos = m_current + 4;
		m_file[i].addr = read();
		m_file[i].size = read();
		seekc(8);
		m_file[i].name = readstr();
		int  len = strlen(m_file[i].name);
		m_current += 20 + (len+4)/4*4;
		return true;
	};
};

ARCFORM::ARCFORM(FILE *in) : Archive(in)
{
	seek(0x10);
	readarray();
	unsigned long header = read();
	seekc(4);
	unsigned long data = read();
	seek(header);
	m_current = header;
	while ((unsigned long)read() != data)
		m_current += 4;
	m_current -= 4;
	m_copy_size = 8;
};
